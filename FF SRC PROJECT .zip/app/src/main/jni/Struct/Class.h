#pragma once
bool PatchOffset(uintptr_t address, const void *buffer, size_t length) {
	unsigned long page_size = sysconf(_SC_PAGESIZE);
    unsigned long size = page_size * sizeof(uintptr_t);
    return mprotect((void *)(address - (address % page_size) - page_size), (size_t) size, PROT_EXEC | PROT_READ | PROT_WRITE) == 0 && memcpy((void *)address, (void *)buffer, length) != 0;
}
bool IsValidEnemy(void *player) {
    static int fd = -1;
    if (fd == -1) {
        fd = open(OBFUSCATE("/dev/random"), O_WRONLY);
    }
    return write(fd, player, 4) >= 0;
}

struct Vvector3 {
    float X;
    float Y;
    float Z;
    Vvector3(): X(0), Y(0), Z(0) {}
    Vvector3(float X1, float Y1, float Z1) : X(X1), Y(Y1), Z(Z1) {}
    Vvector3(const Vvector3 &v);
    ~Vvector3();
};
Vvector3::Vvector3(const Vvector3 &v) : X(v.X), Y(v.Y), Z(v.Z) {}
Vvector3::~Vvector3() {}

struct PlayerID {
    uint32_t NBPDJAAAFBH;
    uint32_t JEDDPHIHGKL;
    uint8_t IOICFFEKAIL;
    uint8_t PHAFNFOFFDB;
    uint64_t BNFAIDHEHOM;
};

static auto get_main() {
    auto (*_get_main)(void *player) = (void *(*)(void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.CoreModule.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Camera"), OBFUSCATE("get_main"), 0);
    return _get_main(nullptr);
}
static auto get_Chars(String *str, int index) {
    auto (*_get_Chars)(String *str, int index) = (char (*)(String *, int))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("mscorlib.dll"), OBFUSCATE("System"), OBFUSCATE("String"), OBFUSCATE("get_Chars"), 1);
    return _get_Chars(str, index);
}
static auto get_Match() {
    auto (*_get_Match)(void *player) = (void *(*)(void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW"), OBFUSCATE("GameFacade"), OBFUSCATE("CurrentMatch"), 0);
    return _get_Match(nullptr);
}
static auto get_CurHP(void *player) {
    auto (*_get_CurHP)(void *player) = (int (*)(void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"), OBFUSCATE("get_CurHP"), 0);
    return _get_CurHP(player);
}
static auto get_MaxHP(void *player) {
    auto (*_get_MaxHP)(void *player) = (int (*)(void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"), OBFUSCATE("get_MaxHP"), 0);
    return _get_MaxHP(player);
}
static auto get_IsFiring(void *player) {
    auto (*_get_IsFiring)(void *player) = (bool (*)(void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"), OBFUSCATE("IsFiring"), 0);
    return _get_IsFiring(player);
}
static auto get_IsDieing(void *player) {
    auto (*_get_IsDieing)(void *player) = (bool (*)(void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"), OBFUSCATE("get_IsDieing"), 0);
    return _get_IsDieing(player);
}
static auto get_HeadTF(void *player) {
    auto (*_get_HeadTF)(void *player) = (void *(*)(void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"), OBFUSCATE("GetHeadTF"), 0);
    return _get_HeadTF(player);
}
static auto get_forward(void *player) {
    auto (*_get_forward)(void *player) = (Vector3 (*)(void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.CoreModule.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Transform"), OBFUSCATE("get_forward"), 0);
    return _get_forward(player);
}
static auto get_Camera(void *player) {
    return *(void **)((uintptr_t) player + (uintptr_t) IL2Cpp::Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"), OBFUSCATE("MainCameraTransform")));
}
static auto get_position(void *player) {
    auto (*_get_position)(void *player) = (Vector3 (*)(void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.CoreModule.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Transform"), OBFUSCATE("get_position"), 0);
    return _get_position(player);
}
static auto get_PlayerID(void *player) {
    auto (*_get_PlayerID)(void *player) = (PlayerID (*)(void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW"), OBFUSCATE("GameFacade"), OBFUSCATE("CurrentLocalPlayerID"), 0);
    return _get_PlayerID(player);
}
static auto get_IsVisible(void *player) {
    auto (*_get_IsVisible)(void *player) = (bool (*)(void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"), OBFUSCATE("IsVisible"), 0);
    return _get_IsVisible(player);
}
static auto get_Rotation(void *player) {
    auto (*_get_Rotation)(void *player) = (Quaternion (*)(void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.CoreModule.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Transform"), OBFUSCATE("get_rotation"), 0);
    return _get_Rotation(player);
}
static auto get_DrawLine(void *player, Vector3 throwPos, Vector3 throwVel, Vector3 gravity) {
    auto (*_get_DrawLine)(void *player, Vector3 throwPos, Vector3 throwVel, Vector3 gravity) = (void (*)(void *, Vector3, Vector3, Vector3))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW"), OBFUSCATE("GrenadeLine"), OBFUSCATE("DrawLine2"), 3);
    return _get_DrawLine(player, throwPos, throwVel, gravity);
}
static auto get_transform(void *player) {
    auto (*_get_transform)(void *player) = (void *(*)(void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.CoreModule.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Component"), OBFUSCATE("get_transform"), 0);
    return _get_transform(player);
}
static auto get_IsSighting(void *player) {
    auto (*_get_IsSighting)(void *player) = (bool (*)(void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"), OBFUSCATE("get_IsSighting"), 0);
    return _get_IsSighting(player);
}
static auto get_LineCount(void *player, int value) {
    auto (*_get_LineCount)(void *player, int value) = (void (*)(void *, int))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.CoreModule.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("LineRenderer"), OBFUSCATE("set_positionCount"), 1);
    return _get_LineCount(player, value);
}
static auto get_deltaTime() {
    auto (*_get_deltaTime)(void *player) = (float (*)(void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.CoreModule.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Time"), OBFUSCATE("get_deltaTime"), 0);
    return _get_deltaTime(nullptr);
}
static auto get_StartFiring(void *player, void *weapon) {
    auto (*_get_StartFiring)(void *player, void *weapon) = (void (*)(void *, void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("PlayerNetwork"), OBFUSCATE("StartFiring"), 1);
    return _get_StartFiring(player, weapon);
}
static auto get_Resolution(int width, int height, bool fullscreen) {
    auto (*_get_Resolution)(int width, int height, bool fullscreen) = (void *(*)(int, int, bool))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.CoreModule.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Screen"), OBFUSCATE("SetResolution"), 3);
    return _get_Resolution(width, height, fullscreen);
}
static auto get_NickName(void *player) {
    auto (*_get_NickName)(void *player) = (String *(*)(void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"), OBFUSCATE("get_NickName"), 0);
    return _get_NickName(player);
}
static auto get_LocalPlayer(void *player) {
    auto (*_get_LocalPlayer)(void *player) = (void *(*)(void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW"), OBFUSCATE("UavMapObject"), OBFUSCATE("GetLocalPlayer"), 0);
    return _get_LocalPlayer(player);
}
static auto get_IsCrouching(void *player) {
    auto (*_get_IsCrouching)(void *player) = (bool (*)(void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"), OBFUSCATE("IsCrouching"), 0);
    return _get_IsCrouching(player);
}
static auto get_LinePosition(void *player, int index, Vector3 position) {
    auto (*_get_LinePosition)(void *player, int index, Vector3 position) = (void (*)(void *, int, Vector3))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.CoreModule.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("LineRenderer"), OBFUSCATE("SetPosition"), 2);
    return _get_LinePosition(player, index, position);
}
static auto get_AimRotation(void *player, Quaternion look) {
    auto (*_get_AimRotation)(void *player, Quaternion lock) = (void (*)(void *, Quaternion))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"), OBFUSCATE("SetAimRotation"), 1);
    return _get_AimRotation(player, look);
}
static auto get_CreateString(const char *str) {
    auto (*_get_CreateString)(void *player, const char *str) = (String *(*)(void *, const char *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("mscorlib.dll"), OBFUSCATE("System"), OBFUSCATE("String"), OBFUSCATE("CreateString"), 1);
    return _get_CreateString(nullptr, str);
}
static auto get_WeaponData(void *player) {
    auto (*_get_WeaponData)(void *player) = (void *(*)(void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("GPBDEDFKJNA"), OBFUSCATE("FCGBLGADKEB"), 0);
    return _get_WeaponData(player);
}
static auto get_HeadCollider(void *player) {
    auto (*_get_HeadCollider)(void *player) = (void *(*)(void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"), OBFUSCATE("get_HeadCollider"), 0);
    return _get_HeadCollider(player);
}
static auto get_IsLocalTeam(void *player) {
    auto (*_get_IsLocalTeam)(void *player) = (bool (*)(void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"), OBFUSCATE("IsLocalTeammate"), 0);
    return _get_IsLocalTeam(player);
}
static auto get_WeaponType(void *player) {
    auto (*_get_WeaponType)(void *player) = (int (*)(void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"), OBFUSCATE("GetWeaponType"), 0);
    return _get_WeaponType(player);
}
static auto get_StartShooting(Vector3 X, Vector3 Y, int recoil , void *mWeapons) {
    auto (*_get_StartShooting)(Vector3 X, Vector3 Y, int recoil , void *mWeapons) = (bool (*)(Vector3, Vector3, int, void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("JEAGCMACNNC"), OBFUSCATE("PLDCHDBCOBF"), 4);
    return _get_StartShooting(X, Y, recoil , mWeapons);
}
static auto get_DamageCount(void *player) {
    auto (*_get_DamageCount)(void *player) = (int (*)(void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("GPBDEDFKJNA"), OBFUSCATE("MEMAEFCDOFL"), 0);
    return _get_DamageCount(player);
}
static auto get_ActiveWeapon(void *player) {
    auto (*_get_ActiveWeapon)(void *player) = (void *(*)(void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"), OBFUSCATE("GetActiveWeapon"), 0);
    return _get_ActiveWeapon(player);
}
static auto get_CurrentUIScene() {
    auto (*_get_CurrentUIScene)(void *player) = (void *(*)(void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW"), OBFUSCATE("GameFacade"), OBFUSCATE("CurrentUIScene"), 0);
    return _get_CurrentUIScene(nullptr);
}
static auto get_LevelMiniSentry(void *player, Vector3 Fire, Vector3 his) {
    auto (*_get_LevelMiniSentry)(void *player, Vector3 Fire, Vector3 his) = (void (*)(void *, Vector3, Vector3))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("LevelMiniSentry"), OBFUSCATE("CPBCGAKODII"), 2);
    return _get_LevelMiniSentry(player, Fire, his);
}
static auto get_WeaponOnHand(void *player) {
    auto (*_get_WeaponOnHand)(void *player) = (void *(*)(void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"), OBFUSCATE("GetWeaponOnHand"), 0);
    return _get_WeaponOnHand(player);
}
static auto get_position_Injected(void *player) {
    auto zero = Vector3::Zero();
    auto (*_get_position_Injected)(void *player, Vector3 *zero) = (void (*)(void *, Vector3 *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.CoreModule.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Transform"), OBFUSCATE("get_position_Injected"), 1);
    _get_position_Injected(player, &zero);
    return zero;
}
static auto set_position_Injected(void *player, Vvector3 position) {
    auto (*_set_position_Injected)(void *player, Vvector3 position) = (void (*)(void *, Vvector3))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.CoreModule.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Transform"), OBFUSCATE("set_position_Injected"), 1);
    return _set_position_Injected(player, position);
}
static auto Network_TakeDamage(void *player, int baseDamage, PlayerID damager, void *damageInfo, int weaponDataID, Vector3 firePos, Vector3 hitPos, List<float>checkParams, void *damagerWeaponDynamicInfo, int damagerVehicleID) {
    auto (*_Network_TakeDamage)(void *player, int baseDamage, PlayerID damager, void *damageInfo, int weaponDataID, Vector3 firePos, Vector3 hitPos, List<float>checkParams, void *damagerWeaponDynamicInfo, int damagerVehicleID) = (int (*)(void *, int, PlayerID, void *, int, Vector3, Vector3, List<float>, void *, int))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("PlayerNetwork"), OBFUSCATE("TakeDamage"), 9);
    return _Network_TakeDamage(player, baseDamage, damager, damageInfo, weaponDataID, firePos, hitPos, checkParams, damagerWeaponDynamicInfo, damagerVehicleID);
}
static auto get_CurrentLocalPlayer() {
    auto (*_get_CurrentLocalPlayer)(void *player) = (void *(*)(void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW"), OBFUSCATE("GameFacade"), OBFUSCATE("CurrentLocalPlayer"), 0);
    return _get_CurrentLocalPlayer(nullptr);
}
static auto get_ShowAssistantText(void *player, String *playerName, String *line, float hp) {
    auto (*_get_ShowAssistantText)(void *player, String *playerName, String *line, float hp) = (void (*)(void *, String *, String *, float))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW"), OBFUSCATE("UIInGameScene"), OBFUSCATE("ShowAssistantText"), 2);
    return _get_ShowAssistantText(player, playerName, line, hp);
}
static auto get_WorldToScreenPoint(void *player, Vector3 position) {
    auto (*_get_WorldToScreenPoint)(void *player, Vector3 position, int eye) = (Vector3 (*)(void *, Vector3, int))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.CoreModule.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Camera"), OBFUSCATE("WorldToScreenPoint"), 2);
    return _get_WorldToScreenPoint(player, position, 4);
}
static auto get_AttackableCenterWS(void *player) {
    auto (*_get_AttackableCenterWS)(void *player) = (Vector3 (*)(void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"), OBFUSCATE("GetAttackableCenterWS"), 0);
    return _get_AttackableCenterWS(player);
}
static auto get_StartWholeBodyFiring(void *player, void *weapon) {
    auto (*_get_StartWholeBodyFiring)(void *player, void *weapon) = (void (*)(void *, void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("PlayerNetwork"), OBFUSCATE("StartWholeBodyFiring"), 1);
    return _get_StartWholeBodyFiring(player, weapon);
}
static auto get_LocalPlayerOrObServer() {
    auto (*_get_LocalPlayerOrObServer)(void *player) = (void *(*)(void *))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW"), OBFUSCATE("GameFacade"), OBFUSCATE("GetLocalPlayerOrObServer"), 0);
    return _get_LocalPlayerOrObServer(nullptr);
}
static auto get_ShowLowPopupMessage(void *player, String *message, float duration) {
    auto (*_get_ShowLowPopupMessage)(void *player, String *message, float duration) = (void (*)(void *, String *, float))(uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW"), OBFUSCATE("UIInGameScene"), OBFUSCATE("ShowLowPopupMessage"), 0);
    return _get_ShowLowPopupMessage(player, message, duration);
}
