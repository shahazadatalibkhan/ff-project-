
#include "Vector3.h"
#include "Vector2.h"
#include "Quaternion.h"

#define HOOK(ret, func, ...) \
    ret (*orig##func)(__VA_ARGS__); \
    ret my##func(__VA_ARGS__)
	
int32_t (*orig_ANativeWindow_getWidth)(ANativeWindow* window);
int32_t _ANativeWindow_getWidth(ANativeWindow* window) {
	screenWidth = orig_ANativeWindow_getWidth(window);
	return orig_ANativeWindow_getWidth(window);
}
int32_t (*orig_ANativeWindow_getHeight)(ANativeWindow* window);
int32_t _ANativeWindow_getHeight(ANativeWindow* window) {
	screenHeight = orig_ANativeWindow_getHeight(window);
	return orig_ANativeWindow_getHeight(window);
}
HOOK(void, Input, void *thiz, void *ex_ab, void *ex_ac) { 
    origInput(thiz, ex_ab, ex_ac);
	ImGui_ImplAndroid_HandleInputEvent((AInputEvent *)thiz, {(float) screenWidth / (float) glWidth, (float) screenHeight / (float) glHeight});
    return;
}
class Rect {
public:
    float X;
    float Y;
    float W;
    float H;
    Rect() {
        this->X = 0;
        this->Y = 0;
        this->W = 0;
        this->H = 0;
    }
    Rect(float X, float Y, float W, float H) {
        this->X = X;
        this->Y = Y;
        this->W = W;
        this->H = H;
    }
	bool operator==(const Rect &src) const {
        return (src.X == this->X && src.Y == this->Y && src.H == this->H && src.W == this->W);
    }
    bool operator!=(const Rect &src) const {
        return (src.X != this->X && src.Y != this->Y && src.H != this->H && src.W != this->W);
    }
};
class ExpireDate {
public:
    ExpireDate() {
        std::time_t now = std::time(nullptr);
        expirationTime = std::chrono::system_clock::from_time_t(now);
    }
    void setExpirationDate(int day, int month, int year) {
        std::tm tm_struct = {};
        tm_struct.tm_mday = day;
        tm_struct.tm_mon = month - 1;
        tm_struct.tm_year = year - 1900;
        std::time_t expirationTime_t = std::mktime(&tm_struct);
        expirationTime = std::chrono::system_clock::from_time_t(expirationTime_t);
    }
    bool isExpired() {
        std::chrono::system_clock::time_point now = std::chrono::system_clock::now();
        return now >= expirationTime;
    }
private:
    std::chrono::system_clock::time_point expirationTime;
};
using namespace std;

float NormalizeAngle (float angle) {
    while (angle>360)
        angle -= 360;
    while (angle<0)
        angle += 360;
    return angle;
}
Vector3 NormalizeAngles (Vector3 angles) {
    angles.X = NormalizeAngle (angles.X);
    angles.Y = NormalizeAngle (angles.Y);
    angles.Z = NormalizeAngle (angles.Z);
    return angles;
}
Vector3 ToEulerRad(Quaternion q1) {
    float Rad2Deg = 360.0 / (M_PI *2.0);
    float sqw = q1.W *q1.W;
    float sqx = q1.X *q1.X;
    float sqy = q1.Y *q1.Y;
    float sqz = q1.Z *q1.Z;
    float unit = sqx + sqy + sqz + sqw;
    float test = q1.X *q1.W - q1.Y *q1.Z;
    Vector3 v;
    if (test>0.4995*unit) {
        v.Y = 2.0 *atan2f (q1.Y, q1.X);
        v.X = M_PI / 2.0;
        v.Z = 0;
        return NormalizeAngles(v *Rad2Deg);
    }
    if (test<-0.4995*unit) {
        v.Y = -2.0 *atan2f (q1.Y, q1.X);
        v.X = -M_PI / 2.0;
        v.Z = 0;
        return NormalizeAngles (v *Rad2Deg);
    }
    Quaternion q(q1.W, q1.Z, q1.X, q1.Y);
    v.Y = atan2f (2.0 *q.X *q.W + 2.0 *q.Y *q.Z, 1 - 2.0 *(q.Z *q.Z + q.W *q.W)); // yaw
    v.X = asinf (2.0 *(q.X *q.Z - q.W *q.Y)); // pitch
    v.Z = atan2f (2.0 *q.X *q.Y + 2.0 *q.Z *q.W, 1 - 2.0 *(q.Y *q.Y + q.Z *q.Z)); // roll
    return NormalizeAngles (v *Rad2Deg);
}

Quaternion LookRotation(Vector3 targetLocation, float y_bias, Vector3 myLoc) {
    return Quaternion::LookRotation((targetLocation + Vector3(0, y_bias, 0)) - myLoc, Vector3(0, 1, 0));
}
