// ============================= { //@ALTAB_VIP========================================== //
// ============================= { //@ALTAB_VIP========================================== //
// ============================= { //@ALTAB_VIP========================================== //
// ============================= { //@ALTAB_VIP========================================== //

#include "EGL/egl.h"
#include "GLES3/gl3.h"
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"
#include "imgui/imgui.h"
#include "imgui/backends/imgui_impl_android.h"
#include "imgui/backends/imgui_impl_opengl3.h"
#include "KittyMemory/MemoryPatch.h"
#include "And64InlineHook/And64InlineHook.hpp"
#include "Substrate/SubstrateHook.h"
#include "Substrate/CydiaSubstrate.h"
#include "YSMTEAM/Call_Me.h"
#include "YSMTEAM/Tools/MonoString.h"
#include "Struct/Unity.h"
#include "Struct/Class.h"
#include "Includes/Macros.h"
//#include "obfuscate.h"
// ============================= { //@ALTAB_VIP========================================== //

#include "Hook.h"
#include "enen/FTools/Iconcpp.h"
#include "enen/FTools/ImguiPP.h"
#include "enen/FTools/Menu.h"
//#include "enen/FTools/Font.h"
#include "enen/FTools/Icon.h"
#include "enen/FTools/StrEnc.h"
#define ALPHA    ( ImGuiColorEditFlags_AlphaPreview | ImGuiColorEditFlags_NoTooltip | ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoLabel | ImGuiColorEditFlags_AlphaBar | ImGuiColorEditFlags_InputRGB | ImGuiColorEditFlags_Float | ImGuiColorEditFlags_NoDragDrop | ImGuiColorEditFlags_PickerHueBar | ImGuiColorEditFlags_NoBorder )
#define NO_ALPHA ( ImGuiColorEditFlags_NoTooltip    | ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoLabel | ImGuiColorEditFlags_NoAlpha | ImGuiColorEditFlags_InputRGB | ImGuiColorEditFlags_Float | ImGuiColorEditFlags_NoDragDrop | ImGuiColorEditFlags_PickerHueBar | ImGuiColorEditFlags_NoBorder )
//#define RealLibToLoad "libYUIM.so"

# define HOOK(offset, ptr, orig) MSHookFunction((void *)getAbsoluteAddress(targetLibName, offset), (void *)ptr, (void **)&orig);

bool setup = false;

void DrawTextCentered(const char *text)
{
//    ImGui::Separator();
    ImGui::SetCursorPosX((ImGui::GetWindowWidth() - ImGui::CalcTextSize(text).x) / 2.f);
    ImGui::Text(text);
//    ImGui::Separator();
}
EGLBoolean (*orig_eglSwapBuffers)(EGLDisplay dpy, EGLSurface surface);
EGLBoolean _eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
	
	eglQuerySurface(dpy, surface, EGL_WIDTH, &glWidth);
	eglQuerySurface(dpy, surface, EGL_HEIGHT, &glHeight);
    
	if (glWidth <= 0 || glHeight <= 0) {
		return eglSwapBuffers(dpy, surface);
	}

    if (!setup){
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
ImGuiStyle *style = &ImGui::GetStyle();
  style->WindowPadding = ImVec2(10, 5);
        style->WindowRounding = 7.0f;
        style->ScrollbarRounding = 10;
        style->FramePadding = ImVec2(5, 4);
        style->FrameRounding = 5.0f;
		style->WindowBorderSize = 2;
		style->FrameBorderSize = 2;

        style->Colors[ImGuiCol_Text]                   = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
style->Colors[ImGuiCol_TextDisabled]           = ImVec4(0.50f, 0.50f, 0.50f, 1.00f);
style->Colors[ImGuiCol_WindowBg]               = ImVec4(0.06f, 0.06f, 0.06f, 0.94f);
style->Colors[ImGuiCol_ChildBg]                = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
style->Colors[ImGuiCol_PopupBg]                = ImVec4(0.08f, 0.08f, 0.08f, 0.94f);

style->Colors[ImGuiCol_Border]                 = ImVec4(0.43f, 0.43f, 0.50f, 0.50f);
style->Colors[ImGuiCol_BorderShadow]           = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);

style->Colors[ImGuiCol_FrameBg]                = ImVec4(0.44f, 0.44f, 0.44f, 0.60f);
style->Colors[ImGuiCol_FrameBgHovered]         = ImVec4(0.57f, 0.57f, 0.57f, 0.70f);
style->Colors[ImGuiCol_FrameBgActive]          = ImVec4(0.76f, 0.76f, 0.76f, 0.80f);

style->Colors[ImGuiCol_TitleBg]                = ImVec4(0.04f, 0.04f, 0.04f, 1.00f);
style->Colors[ImGuiCol_TitleBgActive]          = ImVec4(0.16f, 0.16f, 0.16f, 1.00f);
style->Colors[ImGuiCol_TitleBgCollapsed]       = ImVec4(0.00f, 0.00f, 0.00f, 0.60f);
style->Colors[ImGuiCol_MenuBarBg]              = ImVec4(0.14f, 0.14f, 0.14f, 1.00f);
style->Colors[ImGuiCol_ScrollbarBg]            = ImVec4(0.02f, 0.02f, 0.02f, 0.53f);
style->Colors[ImGuiCol_ScrollbarGrab]          = ImVec4(0.31f, 0.31f, 0.31f, 1.00f);
style->Colors[ImGuiCol_ScrollbarGrabHovered]   = ImVec4(0.41f, 0.41f, 0.41f, 1.00f);
style->Colors[ImGuiCol_ScrollbarGrabActive]    = ImVec4(0.51f, 0.51f, 0.51f, 1.00f);
style->Colors[ImGuiCol_CheckMark]              = ImVec4(0.13f, 0.75f, 0.55f, 0.80f);
style->Colors[ImGuiCol_SliderGrab]             = ImVec4(0.13f, 0.75f, 0.75f, 0.80f);
style->Colors[ImGuiCol_SliderGrabActive]       = ImVec4(0.13f, 0.75f, 1.00f, 0.80f);
style->Colors[ImGuiCol_Button]                 = ImVec4(0.13f, 0.75f, 0.55f, 0.40f);
style->Colors[ImGuiCol_ButtonHovered]          = ImVec4(0.13f, 0.75f, 0.75f, 0.60f);
style->Colors[ImGuiCol_ButtonActive]           = ImVec4(0.13f, 0.75f, 1.00f, 0.80f);

style->Colors[ImGuiCol_Header]                 = ImVec4(0.13f, 0.75f, 0.55f, 0.40f);
style->Colors[ImGuiCol_HeaderHovered]          = ImVec4(0.13f, 0.75f, 0.75f, 0.60f);
style->Colors[ImGuiCol_HeaderActive]           = ImVec4(0.13f, 0.75f, 1.00f, 0.80f);
style->Colors[ImGuiCol_Separator]              = ImVec4(0.13f, 0.75f, 0.55f, 0.40f);
style->Colors[ImGuiCol_SeparatorHovered]       = ImVec4(0.13f, 0.75f, 0.75f, 0.60f);
style->Colors[ImGuiCol_SeparatorActive]        = ImVec4(0.13f, 0.75f, 1.00f, 0.80f);
style->Colors[ImGuiCol_ResizeGrip]             = ImVec4(0.13f, 0.75f, 0.55f, 0.40f);
style->Colors[ImGuiCol_ResizeGripHovered]      = ImVec4(0.13f, 0.75f, 0.75f, 0.60f);
style->Colors[ImGuiCol_ResizeGripActive]       = ImVec4(0.13f, 0.75f, 1.00f, 0.80f);
style->Colors[ImGuiCol_Tab]                    = ImVec4(0.13f, 0.75f, 0.55f, 0.80f);
style->Colors[ImGuiCol_TabHovered]             = ImVec4(0.13f, 0.75f, 0.75f, 0.80f);
style->Colors[ImGuiCol_TabActive]              = ImVec4(0.13f, 0.75f, 1.00f, 0.80f);
style->Colors[ImGuiCol_TabUnfocused]           = ImVec4(0.18f, 0.18f, 0.18f, 1.00f);
style->Colors[ImGuiCol_TabUnfocusedActive]     = ImVec4(0.36f, 0.36f, 0.36f, 0.54f);
//style->Colors[ImGuiCol_DockingPreview]         = ImVec4(0.13f, 0.75f, 0.55f, 0.80f);
//style->Colors[ImGuiCol_DockingEmptyBg]         = ImVec4(0.13f, 0.13f, 0.13f, 0.80f);
style->Colors[ImGuiCol_PlotLines]              = ImVec4(0.61f, 0.61f, 0.61f, 1.00f);
style->Colors[ImGuiCol_PlotLinesHovered]       = ImVec4(1.00f, 0.43f, 0.35f, 1.00f);
style->Colors[ImGuiCol_PlotHistogram]          = ImVec4(0.90f, 0.70f, 0.00f, 1.00f);
style->Colors[ImGuiCol_PlotHistogramHovered]   = ImVec4(1.00f, 0.60f, 0.00f, 1.00f);
style->Colors[ImGuiCol_TableHeaderBg]          = ImVec4(0.19f, 0.19f, 0.20f, 1.00f);
style->Colors[ImGuiCol_TableBorderStrong]      = ImVec4(0.31f, 0.31f, 0.35f, 1.00f);
style->Colors[ImGuiCol_TableBorderLight]       = ImVec4(0.23f, 0.23f, 0.25f, 1.00f);
style->Colors[ImGuiCol_TableRowBg]             = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
style->Colors[ImGuiCol_TableRowBgAlt]          = ImVec4(1.00f, 1.00f, 1.00f, 0.07f);
style->Colors[ImGuiCol_TextSelectedBg]         = ImVec4(0.26f, 0.59f, 0.98f, 0.35f);
style->Colors[ImGuiCol_DragDropTarget]         = ImVec4(1.00f, 1.00f, 0.00f, 0.90f);
style->Colors[ImGuiCol_NavHighlight]           = ImVec4(0.26f, 0.59f, 0.98f, 1.00f);
style->Colors[ImGuiCol_NavWindowingHighlight]  = ImVec4(1.00f, 1.00f, 1.00f, 0.70f);
style->Colors[ImGuiCol_NavWindowingDimBg]      = ImVec4(0.80f, 0.80f, 0.80f, 0.20f);
style->Colors[ImGuiCol_ModalWindowDimBg]       = ImVec4(0.80f, 0.80f, 0.80f, 0.35f);
        style->WindowTitleAlign = ImVec2(0.5f, 0.5f) ;
        style->ScaleAllSizes(std::max(1.0f, density / 150.0f));


     //   ImGui_ImplAndroid_Init();
        ImGui_ImplOpenGL3_Init("#version 300 es");

        ImGuiIO &io = ImGui::GetIO(); 

        io.ConfigWindowsMoveFromTitleBarOnly = true;
        io.IniFilename = NULL;

        static const ImWchar icons_ranges[] = { 0xf000, 0xf3ff, 0 };
        ImFontConfig icons_config;

        ImFontConfig CustomFont;
        CustomFont.FontDataOwnedByAtlas = false;

        icons_config.MergeMode = true;
        icons_config.PixelSnapH = true;
        icons_config.OversampleH = 2.5;
        icons_config.OversampleV = 2.5;

        io.Fonts->AddFontFromMemoryTTF(const_cast<std::uint8_t*>(Custom), sizeof(Custom), 35.0f, &CustomFont);
        io.Fonts->AddFontFromMemoryCompressedTTF(font_awesome_data, font_awesome_size, 29.0f, &icons_config, icons_ranges);
// ============================= { //@ALTAB_VIP========================================== //


        ImFontConfig cfg;
        cfg.SizePixels = ((float) density / 45.0f);
        io.Fonts->AddFontDefault(&cfg);
    ImGui::GetStyle().ScaleAllSizes(3.0f);
    setup = true;
    }
    auto il2cpp_handle = dlopen("libil2cpp.so", 4);
    ImGui_ImplOpenGL3_NewFrame();
	ImGui_ImplAndroid_NewFrame(glWidth, glHeight);
    ImGui::NewFrame();
    DrawESP(ImGui::GetBackgroundDrawList(), glWidth, glHeight, true);
    ImGui::SetNextWindowSize(ImVec2(600, 600), ImGuiCond_Once);
    if (ImGui::Begin(OBFUSCATE("ALTAB_BHAI FREE FIRE SRC"), NULL)) {
    if (ImGui::BeginTabBar("##tabbar", ImGuiTabBarFlags_None)) {
    static int e = 0;
        ImGui::Columns(3);
            ImGui::SetColumnOffset(201, 245);
            {

                    ImGui::Button("   « HACKS MENU »   ");
//ImGui::Toggle("AIMBOT", &Aimbot); //MemoryPatch::createWithHex("libUE4.so", 0x19456CC, "00 00 00 00");
ImGui::Toggle("AIM BOT ", &FF->AimBot);
                    ImGui::Toggle("AIM POR TIRO", &FF->AimFire);
                    ImGui::Toggle("AIM POR MIRA", &FF->AimScope);
                   // ImGui::Toggle(("AIM VISIBLE ", &FF->AimVisible);
					//ImGui::Toggle(("98%HEAD"),&FF->Aimauto);
                    //ImGui::Toggle(("Aim Kill", &FF->AimKill);
                    ImGui::Text("AIM FOV: ");
                    ImGui::SliderFloat("", &FF->AimFov, 0.0f, 100.0f);

            }
             ImGui::NextColumn();
ImGui::Button("  « ESP MENU »  ");               
//ImGui::Toggle("X EFFECT", &xeffect); //MemoryPatch::createWithHex("libUE4.so", 0x1165BF8, "00 00 00 00");
ImGui::Toggle("ESP LINE", &FF->EspLine); ImGui::SameLine(); ImGui::ColorEdit4("##COR DA ESP", Color.line, ALPHA); 
                    ImGui::Toggle("ESP BOX", &FF->EspBox);
					ImGui::Toggle("ESP DISTANCE",&FF->Edistance);
			

             ImGui::NextColumn();
ImGui::Button("  « COLOR MENU »  ");               
ImGui::RadioButton("DEFAULT", &e, 0);
        ImGui::RadioButton("STYLE 1", &e, 1);
         ImGui::RadioButton("STYLE 2", &e, 2);
		        ImGui::RadioButton("STYLE 3", &e, 3);
		        ImGui::RadioButton("STYLE 4", &e, 4);
		        ImGui::RadioButton("STYLE 5", &e, 5);
		        ImGui::RadioButton("STYLE 6", &e, 6);
		      //  ImGui::RadioButton("Tasty Orange", &e, 7);
		       //  ImGui::RadioButton("Nude Green", &e, 9);
switch (e) {
            case 0:
                ImGui::StyleColors3();
                break;
            case 1:
                ImGui::StyleColorsDark();
                break;
            case 2:
                ImGui::StyleColorsLight();
                break;
		    case 3:
                ImGui::StyleColorsDemon();
                break;
			case 4:
                ImGui::StyleColorsSexy();
                break;
                // ============================= { //@ALTAB_VIP========================================== //

			case 5:
                ImGui::StyleColorsMadeByDemon();
                break;
			case 6:
                ImGui::StyleColorsDemonx();
                break;
			case 7:
                ImGui::StyleColorsxdemon(); 
                break;
			case 8:
                ImGui::StyleColorsimdemon();
                break;
			case 9:
                ImGui::StyleColorsdemoncolour();
                break;
			case 10:
                ImGui::StyleColorsClassic();
                break;
}

			}
	
}           
    ImGui::End();
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    return orig_eglSwapBuffers(dpy, surface);
}

void *Init(void *) {
    ProcMap il2cppMap, anogsMap;
    while (!il2cppMap.isValid() && !anogsMap.isValid()) {
		il2cppMap = KittyMemory::getLibraryMap("libil2cpp.so");		
	    anogsMap = KittyMemory::getLibraryMap("libanogs.so");
	    sleep(1);
	}
	

    IL2Cpp::Il2CppAttach();
    
    PatchOffset((uintptr_t)IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("GGP"), OBFUSCATE("IsEmulator"), 0), OBFUSCATE("\x00\x00\xa0\xe3\x1e\xff\x2f\xe1"), 8);
    PatchOffset((uintptr_t)IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("GGP"), OBFUSCATE("ClearCheckData"), 0), OBFUSCATE("\x00\x00\xa0\xe3\x1e\xff\x2f\xe1"), 8);
    PatchOffset((uintptr_t)IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("GAutomationManager"), OBFUSCATE(".ctor"), 0), OBFUSCATE("\x00\x00\xa0\xe3\x1e\xff\x2f\xe1"), 8);
    
    PatchOffset((uintptr_t)IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GCommon"), OBFUSCATE("PlatformUtility_Android"), OBFUSCATE("CheckFileExists"), 1), OBFUSCATE("\x00\x00\xa0\xe3\x1e\xff\x2f\xe1"), 8);
    PatchOffset((uintptr_t)IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GCommon"), OBFUSCATE("PlatformUtility_Android"), OBFUSCATE("CheckEmulatorFiles"), 0), OBFUSCATE("\x00\x00\xa0\xe3\x1e\xff\x2f\xe1"), 8);
    PatchOffset((uintptr_t)IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GCommon"), OBFUSCATE("PlatformUtility_Android"), OBFUSCATE("CheckPackageName"), 1), OBFUSCATE("\x00\x00\xa0\xe3\x1e\xff\x2f\xe1"), 8);
    PatchOffset((uintptr_t)IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GCommon"), OBFUSCATE("PlatformUtility_Android"), OBFUSCATE("CheckEmulatorProperties"), 0), OBFUSCATE("\x00\x00\xa0\xe3\x1e\xff\x2f\xe1"), 8);
    PatchOffset((uintptr_t)IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GCommon"), OBFUSCATE("PlatformUtility_Android"), OBFUSCATE("CheckEmulatorPackageNames"), 0), OBFUSCATE("\x00\x00\xa0\xe3\x1e\xff\x2f\xe1"), 8);

    PatchOffset((uintptr_t)IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"), OBFUSCATE("get_InSwapWeaponCD"), 0), OBFUSCATE("\x00\x00\xa0\xe3\x1e\xff\x2f\xe1"), 8);
        
	//DobbyHook((void *)(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW"), OBFUSCATE("GameConfig"), OBFUSCATE("get_ResetGuest"), 0), (void *)_ResetGuest, (void **)&ResetGuest);
	
    Tools::Hook((void *) (uintptr_t)IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"), OBFUSCATE("GetPhysXState"), 0), (void *) _GetPhysXState, (void **) &GetPhysXState);

   // Tools::Hook((void *) (uintptr_t)IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("AnoSDKNamespace"), OBFUSCATE("IOPOOHPNCKH"), OBFUSCATE("LJGJMOPAEFB"), 0), (void *) &_AntiCrash, (void **) &AntiCrash); // 0x51adda8 Ob44 Đuôi 94
    Tools::Hook((void *) (uintptr_t)IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("KPDMJKOEHEE"), OBFUSCATE("LGINFBPMLAI"), 0), (void *) &_AntiCrash, (void **) &AntiCrash); // 0x11ef43c Ob44 Đuôi 94
    //Tools::Hook((void *) (uintptr_t)IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("ffano"), OBFUSCATE("FNFOLKEMMBG"), OBFUSCATE("CCNEAFOPMIH"), 0), (void *) &_AntiCrash, (void **) &AntiCrash); // 0x4297604 Ob44 Đuôi 94
    Tools::Hook((void *) (uintptr_t)IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW"), OBFUSCATE("UIModelLogin"), OBFUSCATE("DetectAndroidApplications"), 0), (void *) &_AntiCrash, (void **) &AntiCrash); // 0x49cd37c Ob44 Đuôi 94 - DetectAndroidApplications

    //Bypass the 
    Tools::Hook((void *) (uintptr_t)IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW"), OBFUSCATE("LobbyServiceConnectionHandler"), OBFUSCATE("CheckIsInBatchRoom"), 0), (void *) &_AntiCrash, (void **) &AntiCrash); // 0x18778ac Ob44 Đuôi 94
    Tools::Hook((void *) (uintptr_t)IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW"), OBFUSCATE("LobbyServiceConnectionHandler"), OBFUSCATE("CheckIsInRoom"), 0), (void *) &_AntiCrash, (void **) &AntiCrash); // 0x1877a64 Ob44 Đuôi 94
    Tools::Hook((void *) (uintptr_t)IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW"), OBFUSCATE("LobbyServiceConnectionHandler"), OBFUSCATE("OnMsgGin"), 0), (void *) &_AntiCrash, (void **) &AntiCrash); // 0x187bc9c Ob44 Đuôi 94
    Tools::Hook((void *) (uintptr_t)IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW"), OBFUSCATE("LobbyServiceConnectionHandler"), OBFUSCATE("OnMsgAno"), 0), (void *) &_AntiCrash, (void **) &AntiCrash);
    Tools::Hook((void *) (uintptr_t)IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW"), OBFUSCATE("LobbyServiceConnectionHandler"), OBFUSCATE("OnSendDataToClientNtf"), 0), (void *) &_AntiCrash, (void **) &AntiCrash);
    
    Tools::Hook((void *) (uintptr_t)IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("GameVoiceFacade"), OBFUSCATE("Init"), 0), (void *) &_AntiCrash, (void **) &AntiCrash);
    Tools::Hook((void *) (uintptr_t)IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.Gameplay.UGC"), OBFUSCATE("UGCSoundEntity"), OBFUSCATE("GetFlag"), 0), (void *) &_AntiCrash, (void **) &AntiCrash);
    Tools::Hook((void *) (uintptr_t)IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("EJCICONKALE"), OBFUSCATE("MKDOFAHFGHL"), 0), (void *) &_AntiCrash, (void **) &AntiCrash);
    Tools::Hook((void *) (uintptr_t)IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay.UGCRuntime"), OBFUSCATE("MELLNPIFECH"), OBFUSCATE("BLCACOBLOBE"), 0), (void *) &_AntiCrash, (void **) &AntiCrash);
    Tools::Hook((void *) (uintptr_t)IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.CoreModule.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("AndroidJNI"), OBFUSCATE("IsInstanceOf"), 0), (void *) &_AntiCrash, (void **) &AntiCrash);
    
	// ============================= { //@ALTAB_VIP========================================== //
// ============================= { //@ALTAB_VIP========================================== //

	
    //Tools::Hook((void *) (uintptr_t)IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW"), OBFUSCATE("GameConfig") , OBFUSCATE("get_ResetGuest"), 0), (void *) _Guest, (void **) &Guest);
    
    MSHookFunction((void *) (uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"), OBFUSCATE("UpdateBehavior"), 2), (void *)_Update, (void **)& Update);
    
	//stone = MemoryPatch::createWithHex("libunity.so", 0xb8dea0, "00 00 00 00", 4);
	
    MSHookFunction((void *) (uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("PlayerAttributes"), OBFUSCATE("PCFAIFBHFFO"), 0), (void *)_Speed, (void **)&Speed);
    
    //MSHookFunction((void *) (uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("ffano"), OBFUSCATE("FNFOLKEMMBG"), OBFUSCATE("AOCFOHFIAAM"), 2), (void *)_AnoSdk, (void **)&AnoSdk);
    //MSHookFunction((void *) (uintptr_t) IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("ffano"), OBFUSCATE("FNFOLKEMMBG"), OBFUSCATE("CIAFBJBMNKO"), 2), (void *)_AnoSdk, (void **)&AnoSdk);

    Tools::Hook((void *) DobbySymbolResolver(OBFUSCATE("/system/lib/libEGL.so"), OBFUSCATE("eglSwapBuffers")), (void *) _eglSwapBuffers, (void **) &orig_eglSwapBuffers);

    return nullptr;
}

__attribute__((constructor))
void lib_main() 
{
        Tools::Hook((void *) DobbySymbolResolver(OBFUSCATE("/system/lib/libandroid.so"), OBFUSCATE("ANativeWindow_getWidth")), (void *) _ANativeWindow_getWidth, (void **) &orig_ANativeWindow_getWidth);
        Tools::Hook((void *) DobbySymbolResolver(OBFUSCATE("/system/lib/libandroid.so"), OBFUSCATE("ANativeWindow_getHeight")), (void *) _ANativeWindow_getHeight, (void **) &orig_ANativeWindow_getHeight);
        Tools::Hook((void *) DobbySymbolResolver(OBFUSCATE("/system/lib/libinput.so"), OBFUSCATE("_ZN7android13InputConsumer21initializeMotionEventEPNS_11MotionEventEPKNS_12InputMessageE")), (void *) myInput, (void **) &origInput);
        pthread_t pid;
        pthread_create(&pid, nullptr, Init, nullptr);
}
// ============================= { //@ALTAB_VIP========================================== //
// ============================= { //@ALTAB_VIP========================================== //
// ============================= { //@ALTAB_VIP========================================== //
// ============================= { //@ALTAB_VIP========================================== //
// ============================= { //@ALTAB_VIP========================================== //
