#pragma once

#include <curl/curl.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include "Tools/curl/json.hpp"

JavaVM *jvm;
// ============================= { //@ALTAB_VIP========================================== //
// ============================= { //@ALTAB_VIP========================================== //
// ============================= { //@ALTAB_VIP========================================== //
// ============================= { //@ALTAB_VIP========================================== //

using json = nlohmann::json;
std::string g_Token, g_Auth;
static std::string EXP = " ";
bool bValid = false;

struct MemoryStruct {
	char *memory;
	size_t size;
};

static size_t WriteMemoryCallback(void *contents, size_t size, size_t nmemb, void *userp) {
	size_t realsize = size * nmemb;
	struct MemoryStruct *mem = (struct MemoryStruct *) userp;
	
	mem->memory = (char *) realloc(mem->memory, mem->size + realsize + 1);
	if (mem->memory == NULL) {
		return 0;
	}
	memcpy(&(mem->memory[mem->size]), contents, realsize);
	mem->size += realsize;
	mem->memory[mem->size] = 0;
	return realsize;
}

int ShowSoftKeyboardInput() {
	jint result;
	jint flags = 0;
	
	JNIEnv *env;
	jvm->AttachCurrentThread(&env, NULL);
	
	jclass looperClass = env->FindClass(oxorany("android/os/Looper"));
	auto prepareMethod = env->GetStaticMethodID(looperClass, oxorany("prepare"), oxorany("()V"));
	env->CallStaticVoidMethod(looperClass, prepareMethod);
	
	jclass activityThreadClass = env->FindClass(oxorany("android/app/ActivityThread"));
	jfieldID sCurrentActivityThreadField = env->GetStaticFieldID(activityThreadClass, oxorany("sCurrentActivityThread"), oxorany("Landroid/app/ActivityThread;"));
	jobject sCurrentActivityThread = env->GetStaticObjectField(activityThreadClass, sCurrentActivityThreadField);
	
	jfieldID mInitialApplicationField = env->GetFieldID(activityThreadClass, oxorany("mInitialApplication"), oxorany("Landroid/app/Application;"));
	jobject mInitialApplication = env->GetObjectField(sCurrentActivityThread, mInitialApplicationField);
	
	jclass contextClass = env->FindClass(oxorany("android/content/Context"));
	jfieldID fieldINPUT_METHOD_SERVICE = env->GetStaticFieldID(contextClass, oxorany("INPUT_METHOD_SERVICE"), oxorany("Ljava/lang/String;"));
	jobject INPUT_METHOD_SERVICE = env->GetStaticObjectField(contextClass, fieldINPUT_METHOD_SERVICE);
	jmethodID getSystemServiceMethod = env->GetMethodID(contextClass, oxorany("getSystemService"), oxorany("(Ljava/lang/String;)Ljava/lang/Object;"));
	jobject callObjectMethod = env->CallObjectMethod(mInitialApplication, getSystemServiceMethod, INPUT_METHOD_SERVICE);
	
	jclass classInputMethodManager = env->FindClass(oxorany("android/view/inputmethod/InputMethodManager"));
    jmethodID toggleSoftInputId = env->GetMethodID(classInputMethodManager, oxorany("toggleSoftInput"), oxorany("(II)V"));
	
	if (result) {
		env->CallVoidMethod(callObjectMethod, toggleSoftInputId, 2, flags);
	} else {
		env->CallVoidMethod(callObjectMethod, toggleSoftInputId, flags, flags);
	}
	
	env->DeleteLocalRef(classInputMethodManager);
	env->DeleteLocalRef(callObjectMethod);
	env->DeleteLocalRef(contextClass);
    env->DeleteLocalRef(mInitialApplication);
    env->DeleteLocalRef(activityThreadClass);
	jvm->DetachCurrentThread();
	
	return result;
}
// ============================= { //@ALTAB_VIP========================================== //
// ============================= { //@ALTAB_VIP========================================== //
// ============================= { //@ALTAB_VIP========================================== //
// ============================= { //@ALTAB_VIP========================================== //

int PollUnicodeChars() {
	JNIEnv *env;
	jvm->AttachCurrentThread(&env, NULL);
	
	jclass looperClass = env->FindClass(oxorany("android/os/Looper"));
	auto prepareMethod = env->GetStaticMethodID(looperClass, oxorany("prepare"), oxorany("()V"));
	env->CallStaticVoidMethod(looperClass, prepareMethod);
	
	jclass activityThreadClass = env->FindClass(oxorany("android/app/ActivityThread"));
	jfieldID sCurrentActivityThreadField = env->GetStaticFieldID(activityThreadClass, oxorany("sCurrentActivityThread"), oxorany("Landroid/app/ActivityThread;"));
	jobject sCurrentActivityThread = env->GetStaticObjectField(activityThreadClass, sCurrentActivityThreadField);
	
	jfieldID mInitialApplicationField = env->GetFieldID(activityThreadClass, oxorany("mInitialApplication"), oxorany("Landroid/app/Application;"));
	jobject mInitialApplication = env->GetObjectField(sCurrentActivityThread, mInitialApplicationField);
	
	jclass keyEventClass = env->FindClass(oxorany("android/view/KeyEvent"));
	jmethodID getUnicodeCharMethod = env->GetMethodID(keyEventClass, oxorany("getUnicodeChar"), oxorany("(I)I"));
	
	ImGuiIO& io = ImGui::GetIO();
    
	int return_key = env->CallIntMethod(keyEventClass, getUnicodeCharMethod);
	
	env->DeleteLocalRef(keyEventClass);
	env->DeleteLocalRef(mInitialApplication);
    env->DeleteLocalRef(activityThreadClass);
	jvm->DetachCurrentThread();
	
	return return_key;
}

std::string getClipboard() {
	std::string result;
	JNIEnv *env;
	
	jvm->AttachCurrentThread(&env, NULL);
	
	auto looperClass = env->FindClass(oxorany("android/os/Looper"));
	auto prepareMethod = env->GetStaticMethodID(looperClass, oxorany("prepare"), oxorany("()V"));
	env->CallStaticVoidMethod(looperClass, prepareMethod);
	
	jclass activityThreadClass = env->FindClass(oxorany("android/app/ActivityThread"));
	jfieldID sCurrentActivityThreadField = env->GetStaticFieldID(activityThreadClass, oxorany("sCurrentActivityThread"), oxorany("Landroid/app/ActivityThread;"));
	jobject sCurrentActivityThread = env->GetStaticObjectField(activityThreadClass, sCurrentActivityThreadField);
	
	jfieldID mInitialApplicationField = env->GetFieldID(activityThreadClass, oxorany("mInitialApplication"), oxorany("Landroid/app/Application;"));
	jobject mInitialApplication = env->GetObjectField(sCurrentActivityThread, mInitialApplicationField);
	
	auto contextClass = env->FindClass(oxorany("android/content/Context"));
	auto getSystemServiceMethod = env->GetMethodID(contextClass, oxorany("getSystemService"), oxorany("(Ljava/lang/String;)Ljava/lang/Object;"));
	
	auto str = env->NewStringUTF(oxorany("clipboard"));
	auto clipboardManager = env->CallObjectMethod(mInitialApplication, getSystemServiceMethod, str);
	env->DeleteLocalRef(str);
	
	jclass ClipboardManagerClass = env->FindClass(oxorany("android/content/ClipboardManager"));
    auto getText = env->GetMethodID(ClipboardManagerClass, oxorany("getText"), oxorany("()Ljava/lang/CharSequence;"));

    jclass CharSequenceClass = env->FindClass(oxorany("java/lang/CharSequence"));
    auto toStringMethod = env->GetMethodID(CharSequenceClass, oxorany("toString"), oxorany("()Ljava/lang/String;"));

    auto text = env->CallObjectMethod(clipboardManager, getText);
    if (text) {
        str = (jstring) env->CallObjectMethod(text, toStringMethod);
        result = env->GetStringUTFChars(str, 0);
        env->DeleteLocalRef(str);
        env->DeleteLocalRef(text);
    }
    env->DeleteLocalRef(CharSequenceClass);
    env->DeleteLocalRef(ClipboardManagerClass);
    env->DeleteLocalRef(clipboardManager);
    env->DeleteLocalRef(contextClass);
    env->DeleteLocalRef(mInitialApplication);
    env->DeleteLocalRef(activityThreadClass); 	
    jvm->DetachCurrentThread();
    return result.c_str();
}

std::string Login(const char *user_key) {
	JNIEnv *env;
    jvm->AttachCurrentThread(&env, 0);
	
	auto looperClass = env->FindClass(oxorany("android/os/Looper"));
	auto prepareMethod = env->GetStaticMethodID(looperClass, oxorany("prepare"), oxorany("()V"));
	env->CallStaticVoidMethod(looperClass, prepareMethod);
	
	jclass activityThreadClass = env->FindClass(oxorany("android/app/ActivityThread"));
	jfieldID sCurrentActivityThreadField = env->GetStaticFieldID(activityThreadClass, oxorany("sCurrentActivityThread"), oxorany("Landroid/app/ActivityThread;"));
	jobject sCurrentActivityThread = env->GetStaticObjectField(activityThreadClass, sCurrentActivityThreadField);
	
	jfieldID mInitialApplicationField = env->GetFieldID(activityThreadClass, oxorany("mInitialApplication"), oxorany("Landroid/app/Application;"));
	jobject mInitialApplication = env->GetObjectField(sCurrentActivityThread, mInitialApplicationField);
	
	std::string hwid = user_key;
	hwid += Tools::GetAndroidID(env, mInitialApplication);
	hwid += Tools::GetDeviceModel(env);
	hwid += Tools::GetDeviceBrand(env);
	std::string UUID = Tools::GetDeviceUniqueIdentifier(env, hwid.c_str());
	jvm->DetachCurrentThread();
	std::string errMsg;
	
	struct MemoryStruct chunk{};
	chunk.memory = (char *) malloc(1);
	chunk.size = 0;
	
	CURL *curl;
	CURLcode res;
	curl = curl_easy_init();
	
	if (curl) {
		std::string api_key = oxorany("https://attack.software/freepanel/connect");
		if (api_key != api_key) {
			ImGui_ImplAndroid_Shutdown();
            ImGui_ImplOpenGL3_Shutdown();
            ImGui::DestroyContext();        
		}
		curl_easy_setopt(curl, CURLOPT_URL, (api_key.c_str()));
		curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
		curl_easy_setopt(curl, CURLOPT_DEFAULT_PROTOCOL, "https");
		
		struct curl_slist *headers = NULL;
		headers = curl_slist_append(headers, oxorany("Content-Type: application/x-www-form-urlencoded"));
		
		curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
		char data[4096];
		sprintf(data, oxorany("game=PUBG&user_key=%s&serial=%s"), user_key, UUID.c_str());
		curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);
		curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *) &chunk);
		curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
		curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
		
		res = curl_easy_perform(curl);
		if (res == CURLE_OK) {
			try {
				json result = json::parse(chunk.memory);
				if (result[std::string(oxorany("status"))] == true) {
					std::string token = result[std::string(oxorany("data"))][std::string(oxorany("token"))].get<std::string>();
					time_t rng = result[std::string(oxorany("data"))][std::string(oxorany("rng"))].get<time_t>();
					EXP = result[std::string(oxorany("data"))][std::string(oxorany("EXP"))].get<std::string>();
					if (rng + 30 > time(0)) {
						std::string auth = oxorany("PUBG");
						auth += std::string(oxorany("-"));
						auth += user_key;
						auth += std::string(oxorany("-"));
						auth += UUID;
						auth += std::string(oxorany("-"));
						auth += std::string(oxorany("Vm8Lk7Uj2JmsjCPVPVjrLa7zgfx3uz9E"));
						
						std::string outputAuth = Tools::CalcMD5(auth);
						g_Token = token;
						g_Auth = outputAuth;
						bValid = g_Token == g_Auth;
					}
				} else {
					errMsg = result[std::string(oxorany("reason"))].get<std::string>();
				}
			} catch (json::exception &e) {
				errMsg = "{";
				errMsg += e.what();
				errMsg += "}\n{";
				errMsg += chunk.memory;
				errMsg += "}";
			}
		} else {
			errMsg = curl_easy_strerror(res);
		}
	}
	curl_easy_cleanup(curl);
	jvm->DetachCurrentThread();
	return bValid ? "OK" : errMsg;
}

// ============================= { //@ALTAB_VIP========================================== //
// ============================= { //@ALTAB_VIP========================================== //
// ============================= { //@ALTAB_VIP========================================== //
// ============================= { //@ALTAB_VIP========================================== //

