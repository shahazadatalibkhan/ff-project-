// ============================= { //@ALTAB_VIP========================================== //
// ============================= { //@ALTAB_VIP========================================== //
// ============================= { //@ALTAB_VIP========================================== //
// ============================= { //@ALTAB_VIP========================================== //

#pragma once
#include "enen/FTools/Icon.h"
#if defined(__aarch64__) 
    #define RETURN OBFUSCATE("CO 03 5F D6");
    #define TRUE OBFUSCATE("20 00 80 D2 CO 03 5F D6")
    #define FALSE OBFUSCATE("00 00 80 D2 CO 03 5F D6")
    auto androidDataPath = std::string("/storage/emulated/0/Android/data/").append(GetPackageName()).append("/").append(GetPackageName()).append(" [X64]").append(".cs");
#else
    #define RETURN OBFUSCATE("1E FF 2F E1")
    #define TRUE OBFUSCATE("01 00 A0 E3 1E FF 2F E1")
    #define FALSE OBFUSCATE("00 00 A0 E3 1E FF 2F E1")
    auto androidDataPath = std::string("/storage/emulated/0/Android/data/").append(GetPackageName()).append("/").append(GetPackageName()).append(" [X32]").append(".cs");
#endif
struct sColor {
        
        float line[4] = {45 / 255.0f, 180 / 255.0f, 45 / 255.0f, 255 / 255.0f};
        float box[4] = {45 / 255.0f, 180 / 255.0f, 45 / 255.0f, 255 / 255.0f};
        
    };
    
    sColor Color;
    // ============================= { //@ALTAB_VIP========================================== //
// ============================= { //@ALTAB_VIP========================================== //
// ============================= { //@ALTAB_VIP========================================== //
// ============================= { //@ALTAB_VIP========================================== //

   
struct $ {
    bool AimKill = false;
    
    bool AimBot = false;
    bool AimFire = false;
    bool AimScope = false;
    bool AimVisible = false;
    bool Guest = false;
    float AimFov = 0.0f;
    bool TelePro = false;
    bool EspLine = false;
    bool EspBox = false;
	bool StoneHack = false;
	bool Speedrun = false;
	bool Bypass = false;
	bool Aimauto = false;
	bool Edistance = false;
	
};
$ *FF = new $();

bool(*Guest)(void* _this);
bool _Guest(void* _this){
    if (_this != NULL) {
     remove(OBFUSCATE("/storage/emulated/0/com.garena.msdk/guest100067.dat"));
     return true; 
    }
}
float (*Speed)(void *player);
float _Speed(void *player) {
    if (player != nullptr) {
        return 1.4f;
		
    }
    return Speed(player);
}

//DobbyHook((void *)getRealOffset(0x1f793ec), (void *)SPEED_HOOK, (void **)&SPEED_BACKUP);

bool(*orig_Test)(void* _this); 
bool _Test(void* _this) { 
return false;
return orig_Test(_this);
}

void(*MatchMaking)(void* _this); 
void _MatchMaking(void* _this) { 
return;
return MatchMaking(_this);
}
bool(*Bypass)(void* _this);
bool _Bypass(void* _this){
    return false;
}
void(*Yuim)(void* _this); 
void _Yuim(void* _this) {
return;
return Yuim(_this);
}
void (*AnoSdk)(void *player, String Anort, bool e_anosdk);
void _AnoSdk(void *player, String Anort, bool e_anosdk) {
    if (player != nullptr) {
        return;
        e_anosdk = false;
    }
    return AnoSdk(player, Anort, e_anosdk);
}
bool(*AntiCrash)(void*_this, int value);
bool _AntiCrash(void*_this, int value){
    if (_this != NULL) {
        return 10000000;
        return AntiCrash(_this, value);
    }
}
bool(*Hacker)(void* _this);
bool _Hacker(void* _this) {
    if (_this != NULL) {
        return true;
    }
}
int (*GetPhysXState)(void*_this, int value);
int _GetPhysXState(void*_this, int value){
if (_this != NULL) {
		if(FF->TelePro) {
            return 2;
    }
  return GetPhysXState(_this, value);
}
}
bool Visible_Check(void *ClosestEnemy) {
    void *Object = static_cast<void *>(nullptr);
    Vector3 Camera = get_position(get_transform(get_main()));
    Vector3 Collider = get_position(get_transform(get_HeadCollider(ClosestEnemy)));
    if (!get_StartShooting(Camera, Collider, 12, &Object)) {
        return true;
    } else {
        return false;
    }
}

static void TakeDamage(void *ClosestEnemy, Vector3 firePos, Vector3 hitPos) {
    void *damageInfo = *(void **)((uintptr_t) ClosestEnemy);
    if (FF->AimKill && damageInfo != nullptr && Visible_Check(ClosestEnemy)) {
        void *LocalPlayer = get_CurrentLocalPlayer();
        if (LocalPlayer != nullptr) {
            void *WeaponHand = get_WeaponOnHand(LocalPlayer);
            if (WeaponHand != nullptr) {
                void *WeaponDataID = get_WeaponData(WeaponHand);
                if (WeaponDataID != nullptr) {
                    *(int *)((uintptr_t) damageInfo + 0xc) = 1;
                    if (get_WeaponType(LocalPlayer) != 3 || get_WeaponType(LocalPlayer) == 3) {
                        Network_TakeDamage(ClosestEnemy, get_DamageCount(WeaponHand), get_PlayerID(LocalPlayer), damageInfo, *(int *)((uintptr_t) WeaponDataID + (uintptr_t) IL2Cpp::Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("LGCOKIBHIJL"), OBFUSCATE("HBKKNOPECMK"))), firePos, hitPos, *(List<float> *)((uintptr_t) ClosestEnemy + (uintptr_t) IL2Cpp::Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"), OBFUSCATE("OHFDNGOPJNM"))), nullptr, 0);
                    }
                    get_StartWholeBodyFiring(LocalPlayer, WeaponHand);
                }
            }
        }
    }
}
// ============================= { //@ALTAB_VIP========================================== //
// ============================= { //@ALTAB_VIP========================================== //
// ============================= { //@ALTAB_VIP========================================== //
// ============================= { //@ALTAB_VIP========================================== //

void *get_ClosestEnemy(void *Match) {
    if (!Match) {
        return nullptr;
    }
    float max = 1000.0f;
    void *ClosestEnemy = nullptr;
    void *LocalPlayer = get_LocalPlayer(Match);
    if (LocalPlayer != nullptr && !get_IsDieing(LocalPlayer)) {
        Dictionary<uint8_t *, void **> *player = *(Dictionary<uint8_t *, void **> **)((uintptr_t) Match + (uintptr_t) IL2Cpp::Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("NFJPHMKKEBF"), OBFUSCATE("NIEBEGJADLC")));
        for (int i = 0; i < player->getNumValues(); i++) {
            void *LocalEnemy = player->getValues()[i];
            if (IsValidEnemy(LocalEnemy)) {
                if (LocalEnemy != nullptr && !get_IsLocalTeam(LocalEnemy) && !get_IsDieing(LocalEnemy) && get_IsVisible(LocalEnemy) && get_MaxHP(LocalEnemy)) {
                    if (true) {
                        float angle = Vector3::Angle(Vector3::Normalized(get_position(get_HeadTF(LocalEnemy)) - get_position(get_HeadTF(LocalPlayer))), get_forward(get_transform(get_main()))) * 100.0f;
                        if (angle <= FF->AimFov) {
                            if (angle < max) {
                                max = angle;
                                ClosestEnemy = LocalEnemy;
                            }
                        }
                    } else {
                        if (FF->AimFov < max) {
                            max = FF->AimFov;
                            ClosestEnemy = LocalEnemy;
                        }
                    }
                }
            }
        }
    }
    return ClosestEnemy;
}
void (*Update)(void *player);
void _Update(void *player) {
    if (player != nullptr) {
        void *Match = get_Match();
        if (Match != nullptr) {
            void *LocalPlayer = get_LocalPlayer(Match);
            if (LocalPlayer != nullptr) {
                void *ClosestEnemy = get_ClosestEnemy(Match);
                if (ClosestEnemy != nullptr) {
                    void *WeaponHand = get_WeaponOnHand(LocalPlayer);
                    if (WeaponHand != nullptr) {
                        if (FF->AimKill) {
                            TakeDamage(ClosestEnemy, Vector3(get_AttackableCenterWS(LocalPlayer).X, get_AttackableCenterWS(LocalPlayer).Y, get_AttackableCenterWS(LocalPlayer).Z), Vector3(get_position(get_HeadTF(ClosestEnemy)).X, get_position(get_HeadTF(ClosestEnemy)).Y, get_position(get_HeadTF(ClosestEnemy)).Z));
                        }
                    }
                    if (FF->AimBot && get_IsFiring(LocalPlayer) && FF->AimVisible && Visible_Check(ClosestEnemy) || (FF->AimFire && get_IsSighting(LocalPlayer) && FF->AimVisible && Visible_Check(ClosestEnemy) || (FF->AimScope && get_IsCrouching(LocalPlayer) && FF->AimVisible && Visible_Check(ClosestEnemy)))) {
                        get_AimRotation(LocalPlayer, LookRotation(get_position(get_HeadTF(ClosestEnemy)) + (Vector3::Up() * 0.0) + Vector3::Zero(), 0.1f, get_position(get_transform(get_Camera(LocalPlayer)))));
                    } else if (FF->AimBot && get_IsFiring(LocalPlayer) && !FF->AimVisible || (FF->AimFire && get_IsSighting(LocalPlayer) && !FF->AimVisible) || (FF->AimScope && get_IsCrouching(LocalPlayer) && !FF->AimVisible)) {
                        get_AimRotation(LocalPlayer, LookRotation(get_position(get_HeadTF(ClosestEnemy)) + (Vector3::Up() * 0.0) + Vector3::Zero(), 0.1f, get_position(get_transform(get_Camera(LocalPlayer)))));
                    }
                    if (FF->TelePro && 600.99 && LocalPlayer) {
                    void *_TeleKillTP = get_transform(ClosestEnemy);
                    if (_TeleKillTP != NULL) {
                    Vector3 TeleKillTP = get_position_Injected(_TeleKillTP) -(get_forward(_TeleKillTP) * 0);
                    set_position_Injected(get_transform(LocalPlayer),Vvector3(TeleKillTP.X, TeleKillTP.Y, TeleKillTP.Z ));
                   }
                  }
                }
            }
        }
    }
    return Update(player);
}

void DrawESP(ImDrawList *draw, int width, int height, bool fullscreen) {

MemoryPatch::createWithHex("libmain.so", 0x5B1AE, "FD F7 6E BE").Modify();
MemoryPatch::createWithHex("libmain.so", 0x58E98, "00 00 00 00").Modify();
MemoryPatch::createWithHex("libmain.so", 0xD202C, "00 00 00 00").Modify();
MemoryPatch::createWithHex("libmain.so", 0x58EA0, "00 00 00 00").Modify();
MemoryPatch::createWithHex("libmain.so", 0x58E8E, "00 00 00 00").Modify();
MemoryPatch::createWithHex("libmain.so", 0x2AB89C, "00 00 00 00").Modify();
MemoryPatch::createWithHex("libmain.so", 0x9F314, "00 00 00 00").Modify();
MemoryPatch::createWithHex("libmain.so", 0x9F30E, "00 00 00 00").Modify();
MemoryPatch::createWithHex("libmain.so", 0x9F30A, "4F F4 80 61").Modify();
MemoryPatch::createWithHex("libmain.so", 0x9F30E, "00 00 00 00").Modify();
MemoryPatch::createWithHex("libmain.so", 0x9F310, "AF F7 2A ED").Modify();
MemoryPatch::createWithHex("libmain.so", 0x9F314, "00 00 00 00").Modify();
MemoryPatch::createWithHex("libmain.so", 0x9F316, "00 00 00 00").Modify();
MemoryPatch::createWithHex("libmain.so", 0x9F318, "4F F4 80 61").Modify();
MemoryPatch::createWithHex("libmain.so", 0x9F31C, "00 00 00 00").Modify();
MemoryPatch::createWithHex("libmain.so", 0x9F31E, "00 00 00 00").Modify();
MemoryPatch::createWithHex("libmain.so", 0x9F320, "21 F2 DA FF").Modify();
MemoryPatch::createWithHex("libmain.so", 0x9F324, "00 00 00 00").Modify();
MemoryPatch::createWithHex("libmain.so", 0x9F326, "D5 F7 AF F8").Modify();
MemoryPatch::createWithHex("libmain.so", 0x74488, "00 00 00 00").Modify();
MemoryPatch::createWithHex("libmain.so", 0x2C12D8, "00 00 00 00").Modify();

       draw->AddText({((float)density / 11.0f), 300},IM_COL32(66, 245, 221, 255),(ICON_FA_STAR"ALTAB DEVELOPER" ICON_FA_STAR)); 	

// ============================= { //@ALTAB_VIP========================================== //
// ============================= { //@ALTAB_VIP========================================== //
// ============================= { //@ALTAB_VIP========================================== //
// ============================= { //@ALTAB_VIP========================================== //

//draw->AddText({((float)density / 9.0f), 250}, IM_COL32(0, 255, 0, 255),(OBFUSCATE(ICON_FA_TELEGRAM"")));
draw->AddText({((float)density / 11.0f), 257}, IM_COL32(66, 245, 221, 255),(OBFUSCATE("@ALTAB_VIP " )));

    if (!FF->EspLine) return;
    get_Resolution(width, height, fullscreen);
    void *Match = get_Match();
    if (Match != nullptr) {
        void *LocalPlayer = get_CurrentLocalPlayer();
        if (LocalPlayer != nullptr) {
            LocalPlayer = get_LocalPlayerOrObServer();
        }
        if (LocalPlayer != nullptr) {
            Dictionary<uint8_t *, void **> *player = *(Dictionary<uint8_t *, void **> **)((uintptr_t) Match + (uintptr_t) IL2Cpp::Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW.GamePlay"), OBFUSCATE("NFJPHMKKEBF"), OBFUSCATE("NIEBEGJADLC")));
            if (player != nullptr && get_main() != nullptr && player->getNumValues() >= 1) {
                for (int i = 0; i < player->getNumValues(); i++) {
                    void *LocalEnemy = player->getValues()[i];
                    if (LocalEnemy != nullptr && LocalEnemy != LocalPlayer) {
                        if (LocalEnemy != LocalPlayer && LocalEnemy != nullptr && get_IsVisible(LocalEnemy) && !get_IsLocalTeam(LocalEnemy)) {
                            
                            Vector3 PositionRoot = get_WorldToScreenPoint(get_main(), get_position(get_transform(LocalEnemy)));
                            Vector3 PositionHead = get_WorldToScreenPoint(get_main(), get_position(get_HeadTF(LocalEnemy)));
                            if (PositionRoot.Z < 0.0f && PositionHead.Z < 0.0f) {
                                continue;
                            }
                            
                            float distance = Vector3::Distance(get_position(get_transform(LocalPlayer)), get_position(get_transform(LocalEnemy)));
                            float boxHeight = abs(PositionHead.Y - PositionRoot.Y);
							
							//DobbyHook((void *)(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("COW"), OBFUSCATE("GameConfig"), OBFUSCATE("get_ResetGuest"), 0), (void *)_ResetGuest, (void **)&ResetGuest);
							
                            float boxWidth = boxHeight * 0.65f;
                            Rect rect = Rect(PositionHead.X - (boxWidth / 2), (glHeight - PositionHead.Y), boxWidth, boxHeight);
                            
                            if (FF->EspLine) {
                                if (get_IsDieing(LocalEnemy)) {
                                    draw->AddLine(ImVec2((glWidth / 2), 0), ImVec2((glWidth - (glWidth - PositionHead.X)), (glHeight - PositionHead.Y - 8.0f)), IM_COL32(Color.line[0] * 255.0f, Color.line[1] * 255.0f, Color.line[2] * 255.0f, Color.line[3] * 255.0f), 1.5f);
                                } else {
                                    draw->AddLine(ImVec2((glWidth / 2), 0), ImVec2((glWidth - (glWidth - PositionHead.X)), (glHeight - PositionHead.Y - 8.0f)), IM_COL32(Color.line[0] * 255.0f, Color.line[1] * 255.0f, Color.line[2] * 255.0f, Color.line[3] * 255.0f), 1.5f);
                                }
                            }
                            if (FF->EspBox) {
                                if (get_IsDieing(LocalEnemy)) {
                                    int X = rect.X;
                                    int Y = rect.Y;
                                    draw->AddRect(ImVec2(X, Y), ImVec2(X + rect.W, Y + rect.H), IM_COL32(255, 255, 0, 255), 1, 0, 1.5f);
                                } else {
                                    int X = rect.X;
                                    int Y = rect.Y;
                                    draw->AddRect(ImVec2(X, Y), ImVec2(X + rect.W, Y + rect.H), IM_COL32(255, 0, 0, 255), 1, 0, 1.5f);
                                }
								
								// stone = MemoryPatch::createWithHex("libunity.so", 0xb8dea0, "00 00 00 00", 4);
								
                                }
                            }
                        }
                    }
                }
            }
        }
    }
   
